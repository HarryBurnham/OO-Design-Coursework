package main;

import lib.Name;
import lib.Register;

public class RegisterApp {

	public static String execute(Name nm, Register regst) {	
		String cha1 = "a";
		String cha2 = "e";
		String email = "" ;
		Name name;
		String surname = "";
		String firstName ="";
		
		StringBuilder sb = new StringBuilder();
		
		regst.removeName(1);
		regst.addName(nm);
		
		for (int i = 0; i < regst.sizeOfRegister(); i++) {
			name = regst.getName(i);
			if (name.getFirstName().toLowerCase().contains(cha1) || name.getFirstName().toLowerCase().contains(cha2) ) {
				firstName = name.getFirstName().toLowerCase();
				firstName = firstName.substring(0,1);
				surname = name.getFamilyName().toLowerCase();
				surname = surname.substring(0, 3);
				sb.append(firstName + "." + surname + "@email.com\n");
				email = sb.toString();
			} 
			}
	return email;	
}
}