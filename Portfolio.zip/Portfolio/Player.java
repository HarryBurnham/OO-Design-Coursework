package lib;

/**
 * A Player has a name, a rollable and a gamer tag
 * 
 *The Player class uses the Name class and Rollable class
 * The rollable class uses two Die objects to roll and create a score based on 
 * face value
 * 
 * @author P2523292
 *
 */
public class Player implements Comparable<Player> {
 
	//fields 
	private Name name;
	private Rollable rollable;
	private String gamerTag;
	
	//constructors
	/** creates a new instance of Player, using default name and rollable values
	 * the default gamer tag value is "" */
	public Player() {
		name = new Name();
		rollable = new PairOfDice();
		gamerTag ="";
	}
	
	/** Creates a new instance of Player, with the given values. 
     * 
     * @param name the name of the player
     * @param rollable creates two dice objects belonging to the player 
     * @param gamerTag the username of the player 
     */
	public Player(Name name, String gamerTag) {
		this.name = name;
		rollable= new PairOfDice();
		this.gamerTag = gamerTag;
	}
	
	 /** Creates a new instance of Player, with the given values. 
     * 
     * @param name the name of the player
     * @param rollable a pair of dice belonging to the player 
     * @param gamerTag the username of the player 
     * */
	public Player(Name name,String gamerTag,Rollable pairOfDice) {
		this.name = name;
		this.rollable = pairOfDice;
		this.gamerTag = gamerTag;
	}
	
	//methods
	/** Returns the name of the Player 
	 * 
	 * @return name of player 
	 * */
	 public Name getName() {
		 return name;
	 }  
	 
	 /** Sets the value of name to the value specified in the argument
	  * 
	  * @param name the identifier for the Players name 
	  * */
	 public void setName(Name name) {
		 this.name = name; 
	 }
	 
	 /** Returns the pair of dice 
	  * 
	  * @return the dices
	  */
	 public Rollable getRollable() {
		 return rollable;
	 }
	 
	 /** uses the pairOfDice class method of rolling the dice  
	  * to roll both of the players dice
	  *  
	  */
	 public void rollDice() {
		 rollable.roll();
	 }
	 
	 /** Uses the pairOfDice class method of getting the score 
	  *  to return it to the player class
	  * @return pair of dice score
	  */
	 public int getDiceScore() {
		 return rollable.getScore();
	 }
	 
	 /** Returns the gamerTag of the Player 
	  * 
	  * @return gamerTag
	  */
	 public String getGamerTag() {
		 return gamerTag;
	 }
	 
	 /** Sets the value of the gamerTag to the value specified in the argument
	  * 
	  * @param gamerTag the players username 
	  */
	 public void setGamerTag(String gamerTag) {
		 this.gamerTag = gamerTag;
	 }
	   
	 /** Takes a string of a Players name and separates it up and uses the 
	  * Name class to set first and family name for the Player.
	  * @param playerName String that contains the full name to be set
	  */
	 public void setFullPlayerName(String playerName) {
		String firstName = "";
		String surname = "";
		int index = 0;
		
		index = playerName.indexOf(" ");
		firstName = playerName.substring(0,1).toUpperCase() + playerName.substring(1,index).toLowerCase();
		surname = playerName.substring(index+1,index +2).toUpperCase() + playerName.substring(index+2).toLowerCase();
	
		this.name.setFirstName(firstName);
		this.name.setFamilyName(surname);
	 }
	 
	 /** Takes a number and if it is a valid number generates a new gamertag
	  * based upon the Players name and the number provided
	  * @param number that is used to test whether a new gamertag is needed and to use in the gamertag
	  */
	 public void generateGamerTag(int number) {
		 String firstName = "";
		 String surname = "";
		 
		 if (number <= 100 && number >= 0 ) {
			 firstName=this.name.getFirstName().toLowerCase();
			 surname= this.name.getFamilyName().toLowerCase();
			 String reversed1 = new StringBuilder(firstName).reverse().toString();
			 String reversed2 = new StringBuilder(surname).reverse().toString();
			 this.gamerTag = reversed2 + reversed1 + number;
		 }
	 }
	 
	 /** Returns a textual representation of a player
	  * 
	  * @return a textual representation of a player
	  */
	 @Override
	 public String toString() {
	    	return "Player:[name=" + name  + ", gamerTag="+ gamerTag + ", rollable" + rollable + "]";
	    }
	 
	 /** Compares two players together first by name 
	  * and then, if the name is the same, by gamertag
	  * @param other, object to be compared
	  * @return an int value representing true or false
	  */
	 @Override
	 public int compareTo(Player other) {
		  int result = this.name.compareTo(other.name);
		  if (result==0) {
			  result = this.gamerTag.compareTo(other.gamerTag);
		  }
		  return result;
	 }
}
