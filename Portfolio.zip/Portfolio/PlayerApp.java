package main;

import java.util.ArrayList;

import lib.Name;
import lib.Player;

public class PlayerApp {

	public static String execute(ArrayList<Player> participants, int number) {
		
		String firstName = "";
		String surname = "";
		Name name;
		String gamerTag = "";
		String temp = String.valueOf(number);
		String names = "";
		
		StringBuilder sb = new StringBuilder();
		
		for (int i = 0; i < participants.size();i++) {
			name = participants.get(i).getName();
			gamerTag = participants.get(i).getGamerTag().toLowerCase();
			firstName = name.getFirstName().toLowerCase();
			surname = name.getFamilyName().toLowerCase();
			if (gamerTag.contains(surname) && gamerTag.contains(temp)) {
				sb.append(firstName.toUpperCase() + ", " + surname.toLowerCase() + "\n");
				names = sb.toString();
			}
		}
		return names;
	}
}
