package lib;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

/** The Register is a list of names and has a maximum size based on the room
 * 
 * The Register is an ArrayList of names.
 * The maximum size is determined by roomCapacity
 * The Register class implements the Iterable interface 
 *  
 * @author P2523292
 *
 */
public class Register implements Iterable<Name> {

	//fields
	private ArrayList<Name> register;
	private int roomCapacity;
	
	//constructors
	/** Creates a new instance of Register, using default ArrayList values
	 * The default for roomCapacity is 20 */
	public Register() {
		register = new ArrayList<>();
		roomCapacity = 20;
	}
	
	/** creates a new instance of Register, with the given values
	 * 
	 * @param register creates an ArrayList of Name objects
	 * @param roomCapacity that is a maximum amount of objects in the Register
	 */
	public Register(int roomCapacity) {
		register = new ArrayList<Name>();
		this.roomCapacity = roomCapacity;
	}
	
	//methods
	/** Returns the roomCapacity of the Register
	 * 
	 * @return roomCapacity of Register
	 */
	public int getRoomCapacity() {
		return roomCapacity;
	}
	
	/** Adds one name to the list as long as the Register is smaller then the roomCapacity
	 * 
	 * @param n is the name to be added to the Register
	 */
	public void addName(Name n) {
		if (register.size() < roomCapacity) {
		register.add(n);
		}
	}
	
	/** Adds a list of names to the Register as long as the Register is smaller then the roomCapacity
	 * and that adding the whole list will still be less then or equal to the roomCapacity
	 * @param names is the ArrayList of names to be added to the register
	 */
	public void addNames(ArrayList<Name> names ) {
		if ((register.size() < roomCapacity) && ((register.size()+ names.size()) <= roomCapacity)) {
				for (int i = 0; i < names.size(); i++) {
				register.add(names.get(i));
				}
	}
	}
	
	/** Removes the name from the Register and returns it 
	 * 
	 * @param i the index of the name that needs to be removed
	 * @return the name that is removed
	 */
	public Name removeName(int i) {
		return register.remove(i);
	}
	
	/** Finds a name at a specific index in the Register 
	 * 
	 * @param i index of the name to be retrieved
	 * @return the name at specific index
	 */
	public Name getName(int i) {
		return register.get(i);
	}
	
	/** Empties the Register of all names
	 */
	public void clearRegister() {
		register.clear();
	}
	
	/** Returns whether the Register is completely empty
	 * 
	 * @return whether the Register is empty
	 */
	public boolean isRegisterEmpty() {
		return register.isEmpty();
	}
	
	/** Returns whether any of the first names in the Register contains the character inputted
	 * 
	 * @param c the character to be searched for in the first names
	 * @return true or false
	 */
	public boolean searchRegisterByFirstNameInitial(char c) {
		String firstName = "";
		
		for (int i = 0; i < register.size(); i ++) {
			firstName = register.get(i).getFirstName(); 
				if (firstName.charAt(0) == c) {
					return true;
				} 
			}
		return false;
	}
	
	/** Counts how many of a certain first name appears in the Register
	 * 
	 * @param name the first name that is being searched for
	 * @return the number of occurrences
	 */
	public int countFirstNameOccurrences(String name) {
	int count = 0;
	String firstName = ""; 
			
	name = name.toLowerCase();
	
	for (int i = 0; i < register.size(); i ++) {
		firstName = register.get(i).getFirstName().toLowerCase();
		if (firstName.equals(name)){
			count = count + 1;
		}
	}
	return count;
	}
	
	/** Returns the size of the Register
	 *
	 * @return the size of the Register
	 */
	public int sizeOfRegister() {
		return register.size();
	}
	
	public void setName (int index, Name n) {
		if (index >= 0 && index < register.size()) {
		register.remove(index);
		
		register.add(index, n);
		}
	}
	
	/** Sorts the Register using the collections function of Java 
	 */
	public void sortRegister() {
		Collections.sort(register);
	}
	
	 /** Returns a textual representation of the Register
	  * 
	  * @return a textual representation of the Register
	  */
	@Override
	public String toString() {
		return "Register:[register=" + register + ", roomCapacity" + roomCapacity + "]";
	}
	
	/** Overriding the Iterator function so it applies to the Register  
	 * 
	 */
	@Override
	public Iterator<Name> iterator(){
		return register.iterator();
	}
}
