package lib;

public class RegisterX extends Register{

	@Override
	public void addName(Name n) {
		String firstName = n.getFirstName();
		String surname = n.getFamilyName();
		
		firstName = firstName.toUpperCase();
		surname = surname.toUpperCase();
		
		n.setFirstName(firstName);
		n.setFamilyName(surname);
		
		super.addName(n);
	}
}
